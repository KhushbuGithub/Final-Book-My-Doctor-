package com.capgemini.bookmydoctor.exception;

public class AppiontmentBookingException extends RuntimeException {
	public AppiontmentBookingException(String message) {
		super(message);
		
	}

}
