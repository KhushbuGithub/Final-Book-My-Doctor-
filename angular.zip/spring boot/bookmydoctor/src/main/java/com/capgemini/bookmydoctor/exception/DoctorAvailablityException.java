package com.capgemini.bookmydoctor.exception;

public class DoctorAvailablityException extends RuntimeException {
	public DoctorAvailablityException(String message) {
		super(message);
		
	}

}
