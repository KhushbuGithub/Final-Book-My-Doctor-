package com.capgemini.bookmydoctor.exception;

public class RatingException extends RuntimeException{
	public RatingException(String message) {
		super(message);
	}

}
